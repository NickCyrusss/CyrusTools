// Copyright 2016-2020 TriAxis Games L.L.C. All Rights Reserved.


#include "RuntimeMeshModifier.h"

URuntimeMeshModifier::URuntimeMeshModifier()
{

}

void URuntimeMeshModifier::ApplyToMesh_Implementation(FRuntimeMeshRenderableMeshData& MeshData)
{

}

void URuntimeMeshModifier::ApplyToCollisionMesh_Implementation(FRuntimeMeshCollisionData& MeshData)
{

}
